<?
class model{
    public $CNX;
    public function _construct(){
        try{
            $this->CNX = confi
            catch(Exception $e){
                die($e->getMessage());
            }
        }
    }
}
?>