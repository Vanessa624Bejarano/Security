<?php
 $host='localhost';
 $user='root';
 $password='';
 $db='security';

 $conection= @mysqli_connect($host,$user,$password,$db);

 if(!$conection){
    die("Fallo al conectar a la BD: (". $this->con->connect_errno.")"); //Muestra si existe errores 
 }
?>