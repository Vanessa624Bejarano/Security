

<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="style/registro.css">
    <link rel="shortcut icon" href="http://colegiomisaelpastranaborrero.com/img/logo.png" type="Student/favicon.ico">
    <title>Colegio Misael Pastrana Borrero</title>
   
</head>

<body data-spy="scroll" data-target="#navbar" data-offset="57">
    <!-- Header -->
    <nav id="header" class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
        <div class="container ">
            <a class="navbar-brand" href="#">
                <img src="imagenes/logo_colegio.png" alt="Misael Pastrana logo">
                Misael Pastrana Borrero
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbar">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="#main">Inicio</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="sesion.php">Iniciar sesión</a>
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link text-platzi" href='sesion.php'>Registrarse</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Formulario -->
    <section class="contact-box">
        <div class="row no-gutters bg-dark">
            <div class="col-xl-5 col-lg-12 register-bg">
                <div class="position-absolute testiomonial p-4">
                    <h3 class="font-weight-bold text-light">La siguiente revolución digital.</h3>
                    <p class="lead text-light">La nueva etapa de la revolución digital se aproxima.</p>
                </div>
            </div>
            <div class="col-xl-7 col-lg-12 d-flex">
                <div class="container align-self-center p-6">
                    <h1 class="font-weight-bold mb-3">Crea tu cuenta gratis</h1>

                    <p class="text-muted mb-5">Ingresa la siguiente información para registrarte.</p>

                    <form action="controller.php" method="post" class="form-register" >
                        <label class="font-weight-bold">Seleccione su rol <span class="text-danger">*</span></label>
                        <div class="form-row mb-2">

                            <select name="rol" class="desplegable">
                            <option value="0">Seleccione uno</option>
                                <!--Base de datos  -->
                                <?php
                                include_once 'conexion1.php';
                                $sentencia_select = $con->prepare('SELECT * FROM rol');
                                $sentencia_select->execute();
                                $resultado = $sentencia_select->fetchALL();
                                ?>
                                <?php foreach ($resultado as $opciones) : ?>
                                

                                    <option value="<?php echo $opciones['idRol']; ?>"><?php echo $opciones['Rol']; ?></option>

                                <?php endforeach ?>

                                <!--Base de datos  -->


                            </select>
                        </div>

                        <div class="form-row mb-2">

                            <div class="form-group col-md-6">
                                <label class="font-weight-bold">Tipo de documento <span class="text-danger">*</span></label>
                                <div class="form-row mb-2">

                                    <select name="tipid" class="desplegable">
                                    <option value="0">Seleccione uno</option>
                                        <!--Base de datos  -->
                                        <?php
                                        include_once 'conexion1.php';
                                        $sentencia_select = $con->prepare('SELECT * FROM tipoidpersona');
                                        $sentencia_select->execute();
                                        $resultado = $sentencia_select->fetchALL();
                                        ?>
                                        <?php foreach ($resultado as $opciones) : ?>
                                           

                                            <option value="<?php echo $opciones['IdTipo']; ?>"><?php echo $opciones['NombreTipoId']; ?></option>

                                        <?php endforeach ?>

                                        <!--Base de datos  -->


                                    </select>
                                </div>

                            </div>
                            
                        </div>
                        <div class="form-row mb-2">

                            <div class="form-group col-md-6">
                                <label class="font-weight-bold">Numero de documento <span class="text-danger">*</span></label>
                                <input type="text" name="numid" class="form-control" placeholder="Tu identificacion">
                            </div>
                        </div>
                        <div class="form-row mb-2">
                            <div class="form-group col-md-6">
                                <label class="font-weight-bold">Primer nombre <span class="text-danger">*</span></label>
                                <input type="text" name="n1" class="form-control" placeholder="Tu nombre">
                            </div>
                            <div class="form-group col-md-6">
                                <label class="font-weight-bold">Segundo nombre </label>
                                <input type="text" name="n2" class="form-control" placeholder="Tu apellido">
                            </div>
                        </div>
                        <div class="form-row mb-2">
                            <div class="form-group col-md-6">
                                <label class="font-weight-bold">Primer apellido <span class="text-danger">*</span></label>
                                <input type="text" name="a1" class="form-control" placeholder="Tu nombre">
                            </div>
                            <div class="form-group col-md-6">
                                <label class="font-weight-bold">Segundo apellido </label>
                                <input type="text" name="a2" class="form-control" placeholder="Tu apellido">
                            </div>
                        </div>
                        <div class="form-group mb-3">
                            <label class="font-weight-bold">Correo electrónico <span class="text-danger">*</span></label>
                            <input type="email" name="email" class="form-control" placeholder="Ingrese su correo electrónico">
                        </div>

                        <div class="form-group mb-3">
                            <label class="font-weight-bold">Numero de telefono <span class="text-danger">*</span></label>
                            <input type="tel" name="cel" class="form-control" placeholder="Ingrese tu correo electrónico">
                        </div>

                        <div class="form-row mb-2">
                            <div class="form-group col-md-6">
                                <label class="font-weight-bold">Contraseña <span class="text-danger">*</span></label>
                                <input type="password" name="passwo" class="form-control" placeholder="Ingrese su Contraseña">
                            </div>
                            <div class="form-group col-md-6">
                                <label class="font-weight-bold">Confirmar Contraseña <span class="text-danger">*</span></label>
                                <input type="password" name="pass2" class="form-control" placeholder="Repita su Contraseña">
                            </div>


                            <div class="form-group mb-5">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox">
                                    <label class="form-check-label text-muted">Al seleccionar esta casilla aceptas nuestro
                                        aviso de privacidad y los términos y condiciones</label>
                                </div>
                            
                                <input class="btn btn-primary width-100" type="submit" name="enviar" value="Enviar">
                             
                               
                               
  
             </div>
                           

                            <?php include("controller.php"); ?>

                    

                           
                    </form>
                    <small class="d-inline-block text-muted mt-5">Todos los derechos reservados | © 2019
                        Templune</small>
                </div>
            </div>
        </div>
    </section>


    <!-- Formulario -->








    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
   

</body>