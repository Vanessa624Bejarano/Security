<?php 

include("conexion.php"); // incluye el archivo conexion.php el cual se conecta a la base de datos

$df=new conexion;

class clases extends conexion 

{ // Crea una clase que hereda de la clase conexión 
    
    public function registro($a,$b,$c,$d,$e,$f,$g,$h,$i,$j) //Método que verifica si el usuario existe 
    { 
        $q = "INSERT INTO `usuarios`(`Nu_doc`, `Tipo_doc`, `Primer_nom`, `Segundo_nom`, `Primer_ape`, `Segundo_ape`, `Num_tel`, `Contras`, `Answer`, `Pregun_idpregunta`, `id_Rol`, `pc`, `Correo`) VALUES ('$c','$b','$d','$e','$f','$g','$i','$j',1,1,'$a',12,'$h')"; 
        $consulta = $this->con->query($q) or die ('Error!' . $this->con->error); 
        return $consulta; 
    }
}
?>