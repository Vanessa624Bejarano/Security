
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">


    <title>Iniciar Sesión</title>
</head>

<body>
  
<form  action="" method="post">
                        
                        <div class="form-row mb-2">

                            <div class="form-group mb-3">
                                <label class="font-weight-bold">Documento <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="numid" placeholder="Tu Documento">
                            </div>
                            <div class="form-group mb-3">
                                <label class="font-weight-bold">Contraseña <span class="text-danger">*</span></label>
                                <input type="password"  class="form-control" name="passwo" placeholder="Ingresa tu contraseña">
                            </div>

                            <div class="form-group mb-5">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox">
                                    <label class="form-check-label text-muted">Al seleccionar esta casilla aceptas
                                        nuestro
                                        aviso de privacidad y los términos y condiciones</label>
                                </div>
                                <?php
$alert='';
if(!empty($_POST))
{
  if(empty($_POST['numid'])|| empty($_POST['passwo'])){
    echo $alert='Ingrese su usuario y su clave';
  }
  else{
      require_once "conectado.php";
      $user=$_POST['numid'];
      $pass=$_POST['passwo'];
      $query=mysqli_query($conection,"SELECT * FROM usuarios WHERE Nu_doc= '$user' AND Contras='$pass'");
      $result= mysqli_num_rows($query);

      if($result>0){
          $data = mysqli_fetch_array($query);
          session_start();
          $_SESSION['active']=true;
          $_SESSION['Nu_doc']=$data['Nu_doc'];
          $_SESSION['nombre']=$data['Primer_nom'];
          

      }
  }
}
?>

                              
                            </div>
                            
                            <input type="submit" value="Ingresar" >
                    </form>               
                </div>
            </div>
    


</body>

</html>