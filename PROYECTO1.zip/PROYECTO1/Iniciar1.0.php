<?php
$alert='';
if(!empty($_POST))
{
  if(empty($_POST['numid'])|| empty($_POST['passwo'])){
    echo $alert='Ingrese su usuario y su clave';
  }
  else{
      require_once "conectado.php";
      $user=$_POST['numid'];
      $pass=$_POST['passwo'];
      $query=mysqli_query($conection,"SELECT * FROM usuarios WHERE Nu_doc= '$user' AND Contras='$pass'");
      $result= mysqli_num_rows($query);

      if($result>0){
          $data = mysqli_fetch_array($query);

          print_r($data);
      }
  }
}
?>

<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,700&display=swap" rel="stylesheet">
    <link href="https://unpkg.com/ionicons@4.5.10-0/dist/css/ionicons.min.css" rel="stylesheet">
    <link href="style/Iniciar.css" rel="stylesheet">
    <link rel="shortcut icon" href="http://colegiomisaelpastranaborrero.com/img/logo.png" type="Student/favicon.ico">

    <title>Iniciar Sesión</title>
</head>

<body>
    <img src="https://www.colegiomisaelpastranaborrero.com/wp-content/uploads/resized/9f6a087e4cba0bff916fade1081be126/olipiadas.jpg"
        alt="col-misaelpborrero" class="TRY">
    <section class="contact-box">
        <div class="row no-gutters bg-dark">
            <div class="col-xl-5 col-lg-12 register-bg">
                <div class="position-absolute testiomonial p-4">

                    <h3 class="font-weight-bold text-light">Accede a tu información.</h3>
                    <p class="lead text-light">Facil acceso y mas seguridad en tu institución.</p>

                </div>
            </div>
            <div class="col-xl-7 col-lg-12 d-flex">

                <div class="container align-self-center p-6">
                    <h1 class="font-weight-bold mb-3">Inicia Sesión</h1>
                    <p class="text-muted mb-5">Ingresa la siguiente información para Iniciar Sesión.</p>

                    <form>
                        <label class="font-weight-bold">Selecciona Tu Rol <span class="text-danger">*</span></label>
                        <div class="form-row mb-2">
                            <select name="transporte" class="form-control">

                                <option>Estudiante</option>

                                <option>Docente</option>

                                <option selected>Acudiente</option>

                                <option selected>Administrador</option>

                            </select>
                        </div>
                        <div class="form-row mb-2">

                            <div class="form-group mb-3">
                                <label class="font-weight-bold">Correo electrónico <span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="numid" placeholder="Ingresa tu correo electrónico">
                            </div>
                            <div class="form-group mb-3">
                                <label class="font-weight-bold">Contraseña <span class="text-danger">*</span></label>
                                <input type="password" class="form-control" name="passwo" placeholder="Ingresa una contraseña">
                            </div>

                            <div class="form-group mb-5">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox">
                                    <label class="form-check-label text-muted">Al seleccionar esta casilla aceptas
                                        nuestro
                                        aviso de privacidad y los términos y condiciones</label>
                                </div>
                            </div>
                            <input type="submit" value="Ingresar" >
                    </form>
                    <small class="d-inline-block text-muted mt-5">Todos los derechos reservados | © 2021
                        Security Innovation</small>
                </div>
            </div>
        </div>
    </section>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
        crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
        crossorigin="anonymous"></script>
</body>

</html>