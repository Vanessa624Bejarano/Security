<?php
class config{
    
}

?>