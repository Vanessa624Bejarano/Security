<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"
        integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="style/index.css">
    <link rel="shortcut icon" href="http://colegiomisaelpastranaborrero.com/img/logo.png" type="Student/favicon.ico">
    <title>Colegio Misael Pastrana Borrero</title>
</head>

<body data-spy="scroll" data-target="#navbar" data-offset="57">
    <!-- Header -->
    <nav id="header" class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
        <div class="container ">
            <a class="navbar-brand" href="#">
                <img src="imagenes/logo_colegio.png" alt="Misael Pastrana logo">
                Misael Pastrana Borrero
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbar">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="#main">Inicio</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#speakers">Horizonte Institucional</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#place-time">El lugar</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-platzi" href="registro.php">Registrarse</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- /Header -->

    <!-- Main -->
    <main id="main">
        <div id="carousel" class="carousel slide carousel-fade" data-ride="carousel" data-pause="false">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img class="d-block w-100" src="imagenes/fondo 1.jpg" alt="">
                </div>
                <div class="carousel-item">
                    <img class="d-block w-100" src="imagenes/fondo 2.jpg" alt="">
                </div>
                <div class="carousel-item">
                    <img class="d-block w-100" src="imagenes/fondo 3.jpg" alt="Cargando 3">
                </div>
                <div class="overlay">
                    <div class="container">
                        <div class="row align-items-center">
                            <div class="col-md-6 offset-md-6 text-center text-md-right">
                                <h1>Misael Pastrana Borrero</h1>
                                <p class="d-none d-md-block">
                                    En Colegio IED Misael Pastrana Borrero ofrecemos un enriquecedor
                                    ambiente de estudios. Nos enorgullecen nuestros estudiantes,
                                    nuestros profesores y todas las personas de la comunidad educativa.
                                    Quienes siempre están buscando aprender, crear y crecer juntos.
                                </p>

                                <a href="registro.php" class="btn btn-outline-light">Registrarse</a>
                                <a href="Iniciar.html" class="btn btn-platzi">
                                    Ingresar</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <!-- /Main -->

    <!-- Speakers -->
    <section id="speakers" class="mt-4">
        <div class="container">
            <div class="row">
                <div class="col text-center text-uppercase">
                    <small>Horizonte</small>
                    <h2>Institucional</h2>
                </div>
            </div>
            <div class="row">
                <div class="col-12 col-md-6 col-lg-4 mb-4">
                    <div class="card">
                        <img class="card-img-top" src="imagenes/mision.png" alt="Foto de Misión">
                        <div class="card-body">

                            <h5 class="card-title">Misión</h5>
                            <p class="card-text">El Colegio Misael Pastrana Borrero, es una Institución Educativa
                                Distrital con un claro compromiso para la transformación social y cultural de sus
                                estudiantes que propende por la garantía de los derechos de su población y que desde
                                el enfoque de la pedagogía crítica ofrece un ambiente agradable y acogedor para la
                                formación
                                ntegral de los niños y jóvenes en busca de su permanente superación..</p>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-4 mb-4">
                    <div class="card">
                        <img class="card-img-top" src="imagenes/valores.jpg" alt="Valores">
                        <div class="card-body">

                            <h5 class="card-title"> Valores </h5>
                            <p class="card-text">Los valores que destacan a la comunidad del Colegio son: Solidaridad,
                                Respeto y Colaboración. Que se evidencian actitudes de Lealtad, Tolerancia y Sentido de
                                Pertenencia.
                                <br> <br> <br>

                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-4 mb-4">
                    <div class="card">
                        <img class="card-img-top" src="imagenes/egresado.png" height="200" alt=" Perfil del Egresado ">
                        <h5 class="card-title">Perfil del Egresado</h5>
                        <p class="card-text">Ser humano íntegro, consciente, crítico y cultivador de la vida y la
                            alteridad
                            en su entorno cercano como parte del planeta. Que se valore en sus capacidades y
                            potencialidades
                            como persona y actor social.<br>
                            ​Capaz de pensar, comunicar, promover y valorar transformaciones positivas en la
                            problemática básica de los
                            contextos en los que se desenvuelve o aspira proyectarse de manera interdisciplinar,
                            mediante el uso pertinente
                            de diversas tecnologías.</p>
                    </div>
                </div>
            </div>

        </div>

        <!-- Lugar y fecha -->
        <section id="place-time">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-lg-6 pl-0 pr-0">
                        <img src="imagenes/fondo 4.jpg" alt="....." />
                    </div>
                    <div class="col-12 col-lg-6 pt-4 pb-4">
                        <h2>Colegio Misael Pastrana Borrero (IED)</h2>
                        <p>
                            La IED Colegio Misael Pastrana Borrero es una institución
                            oficial que ofrece el servicio de educación formal,
                            en los niveles de educación preescolar, educación básica
                            (primaria y secundaria) y media. Está ubicado en el barrio
                            las Lomas, en la localidad 18 Rafael Uribe Uribe al sur oriente
                            de la ciudad de Bogotá. A partir del año 2001 la escuela se transforma
                            en colegio y amplia su cobertura ala educación básica secundaria y
                            a partir del año 2003 a educación media,convirtiéndose a partir de
                            entonces en Institución Educativa Distrital.Las nuevas características
                            de la institución llevan a la comunidad educativa a replantear el PEI,
                            para que este pueda responder a los intereses de la toda lapoblación
                            estudiantil.
                        </p>
                        <a class="btn btn-outline-light" href="https://www.colegiomisaelpastranaborrero.com/"
                            target="_blank">Conoce
                            más</a>
                    </div>
                </div>
            </div>
        </section>
        <!-- /Lugar y fecha -->

        <section id="conviertete" class="pt-3 pb-3">
            <div class="container">
                <div class="row">
                    <div class="col text-uppercase text-center">
                        <small>Tienes alguna </small>
                        <h2>Pregunta comunicate y te responderemos</h2>
                    </div>
                </div>
                <div class="row">
                    <div class="col text-center">
                        <abbr data-toggle="tooltip" title="Charlas de 5 minutos"></abbr>
                        Cuéntanos que pregunta quieres saber de Security Innovation !
                    </div>
                </div>
                <div class="row">
                    <div class="col col-md-10 offset-md-1 col-lg-8 offset-lg-2 pt-2">
                        <form>
                            <div class="form-row">
                                <div class="form-group col-12 col-md-6">
                                    <input type="text" class="form-control" placeholder="Nombre">
                                </div>
                                <div class="form-group col-12 col-md-6">
                                    <input type="text" class="form-control" placeholder="Correo electronico">
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col">
                                    <textarea name="text" class="form-control form-control-lg"
                                        placeholder="Sobre qué quieres hablar?"></textarea>
                                    <small class="form-text text-muted">
                                        Recuerda comunicarte con nosotros
                                    </small>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="col">
                                    <button type="button" class="btn btn-platzi btn-block">Enviar</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>


        <!-- Footer -->
        <footer id="footer" class="pb-4 pt-4">
            <div class="container">
                <div class="row text-center">
                    <div>
                        <img src="imagenes/logo.png" width="60">
                    </div>
                    <div class="col-12 col-lg">
                        <a href="#">Preguntas frecuentes</a>
                    </div>
                    <div class="col-12 col-lg">
                        <a href="#">Contáctanos</a>
                    </div>

                    <div class="col-12 col-lg">
                        <a href="#">Términos y condiciones</a>
                    </div>
                    <div class="col-12 col-lg">
                        <a href="#">Privacidad</a>
                    </div>

                </div>
            </div>
        </footer>
        <!-- /Footer -->

        <!-- Modal -->
        <div class="modal fade" id="modalCompra" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalCenterTitle">Contactanos</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form>
                            <div class="form-row">
                                <div class="form-group col">
                                    <div class="input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="basic-addon1">@</span>
                                        </div>
                                        <input type="text" class="form-control" placeholder="Username"
                                            aria-label="Username" aria-describedby="basic-addon1">
                                    </div>
                                </div>
                            </div>
                        </form>
                        <div class="alert alert-warning" role="alert">
                            Recibirás un correo de confirmación
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                        <button type="button" class="btn btn-platzi">Comprar</button>
                    </div>
                </div>
            </div>
        </div>
        <!-- /Modal -->
      
        <!-- Optional JavaScript -->
        <!-- jQuery first, then Popper.js, then Bootstrap JS -->
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
            integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
            crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"
            integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
            crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"
            integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy"
            crossorigin="anonymous"></script>
        <script src="index.js"></script>
        
        </body>

</html