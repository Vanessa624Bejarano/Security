<?php
	include_once 'conexion1.php';
	$sentencia_select=$con->prepare('SELECT * FROM usuarios ORDER BY Nu_doc ASC');
	$sentencia_select->execute();
	$resultado=$sentencia_select->fetchALL();

	//Método Buscar
	if(isset($_POST['btn_buscar'])){
		$buscar_text=$_POST['buscar'];
		$select_buscar=$con->prepare('SELECT * FROM usuarios WHERE Primer_nom LIKE :campo OR Primer_ape LIKE :campo;');
		$select_buscar->execute(array(':campo' =>"%".$buscar_text."%"));
		$resultado=$select_buscar->fetchAll();
	}

    session_start();
if(empty($_SESSION['active'])){
  header('location:sesion.php');
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap  -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <!--asomefont-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0-1/css/all.min.css"
        integrity="sha512-wDB6AYiYP4FO5Sxieamqy9wtpAY3qdHMqlhZecIEUu1YjkLw5gQf/4ZDgOzmCBAF5SheMjmugkpUSVoUrGbLkQ=="
        crossorigin="anonymous" />
	<link rel="stylesheet" type="text/css" href="Estilo.css">
	<link rel="shortcut icon" href="http://colegiomisaelpastranaborrero.com/img/logo.png" type="Student/favicon.ico">
    <title>Perfil_admin</title>
</head>
<body class="bodybg">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#"><img src="./imagenes/logo_colegio.png" class="logoi" alt="logo">Misael
                Pastrana
                Moreno</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ullinks">
                    <li class="nav-item">
                        <a class="nav-link" id="huella"  href=salir.php><i class="fas fa-arrow-circle-left  fa-2x"></i>Salir</a>
                    </li>
					<li class="nav-item">
                        <a class="nav-link " id="huella" href="#"><i class="far fa-user fa-2x"></i>Admin</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="huella" aria-current="page" href="index.php"><i
                                class="fas fa-home fa-2x"></i>
                            Home</a>
                    </li>
                   
					<li class="nav-item">
                        <a class="nav-link"  id="huella" aria-current="page" href="index.php"><i
						class="fas fa-user-plus fa-2x"></i>
                            Crear</a>
                    </li>
					
                </ul>
            </div>
        </div>
    </nav><br>
	<div class="container-fluid">
        <table class="table">
            <thead class="table-dark">
                <tr class="encabezado">
                    <th scope="col">Id - Admin</Id-docente>
                    </th>
                    <th scope="col">Nombre admin</th>
                    <th scope="col">Apellidos admin</th>
                    
					
                </tr>
            </thead>
            <tbody>
                <tr class="celda">
                <td><?php echo $_SESSION['a']?></td>
                    <td><?php echo  $_SESSION['b'],' ',$_SESSION['c']?></td>
                    <td><?php echo  $_SESSION['d'],' ',$_SESSION['e']?></td>
                   
                    

                </tr>
            </tbody>
        </table>
        
	<div class="contenedor">
		
		<div class="barra__buscador">
			<form action="" class="formulario" method="POST">
				<input type="text" name="buscar" placeholder="buscar nombre o apellido" class="input__text"
				 value="<?php if(isset($buscar_text))
				 {echo $buscar_text;}?>">
				<input type="submit" class="btn" name="btn_buscar" value="buscar">
				<a href="insertar.php" class="btn" name="btn__nuevo">Nuevo</a>
			</form>
		</div>
        <!--Lista usuarios-->
		<table>
			<tr class="encabezado">
				<td>Id</td>
				<td>Nombres</td>
			
				<td colspan="2">Acción</td>
			</tr>
			<?php foreach ($resultado as $fila):?>
				<tr class="celda">
					<td><?php echo $fila ['Nu_doc']; ?></td>
					<td><?php echo $fila['Primer_nom']; ?></td>
					
					<td><a href="editar.php?id=<?php echo $fila['Nu_doc']; ?>" class="btn__update">Editar</a></td>
					<td><a href="delete.php?Id=<?php echo $fila['Nu_doc']; ?>" class="btn__delete">Eliminar</a></td>
				</tr>
				<?php endforeach ?>
				
		</table>
	</div>
	
    <!--footer-->
    <footer class=" footer bg-dark">
        <div class="footer mt-2 container-fluid bg-dark pt-2">
            <div class="float-left m-1">
                <div class="row text-center">
                    <img class="security_logo" src="imagenes/logo.png">
                    <div class="col-12 col-lg">
                        <a href="#">Preguntas frecuentes</a>
                    </div>
                    <div class="col-12 col-lg">
                        <a href="#">Privacidad</a>
                    </div>
                    <div class="col-12 col-lg">
                        <a href="#">Términos y condiciones</a>
                    </div>
                    <div class="col-12 col-lg">
                        <a href="#">Ayuda</a>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Bootstrap Bundle with Popper javascrip-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW"
        crossorigin="anonymous"></script>
</body>
</html>