<?php

include("clases.php"); //Trae el archivo clases.php en cual se creara más adelante

if (isset($_REQUEST["enviar"])) { // Verifica si el botón oprimido es el de registro

    $rol = $_REQUEST['rol'];
    $tipid = $_REQUEST['tipid'];
    $numid = $_REQUEST['numid'];
    $n1 = $_REQUEST['n1'];
    $n2 = $_REQUEST['n2'];
    $a1 = $_REQUEST['a1'];
    $a2 = $_REQUEST['a2'];
    $email = $_REQUEST['email'];
    $cel = $_REQUEST['cel'];
    $passwo = $_REQUEST['passwo'];

    $passwo = password_hash($passwo, PASSWORD_DEFAULT); //Encriptación de la contraseña digitada

    $objeto = new clases; // Creación de un objeto de la clase clases del archivo clases.php 
    $res = $objeto->registro($rol,$tipid,$numid,$n1,$n2,$a1,$a2,$email, $cel,$passwo);
    
$msg = "ok";
header("location:Iniciar.php?respuesta=$msg");
}



    



