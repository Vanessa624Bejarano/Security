<?php
$alert='';
session_start();
if(!empty($_SESSION['active'])){
  header('location:admin.php');
}
else{


if(!empty($_POST))
{
  if(empty($_POST['numid'])|| empty($_POST['passwo'])){
    echo $alert='Ingrese su usuario y su clave';
  }
  else{
      require_once "conectado.php";
      $user=mysqli_real_escape_string($conection,$_POST['numid']);//caracteres extraños que pueden hackear
      $pass=mysqli_real_escape_string($conection,$_POST['passwo']);
      $query=mysqli_query($conection,"SELECT * FROM usuarios WHERE Nu_doc= '$user' AND Contras='$pass'");
      $result= mysqli_num_rows($query);

      if($result>0){
          $data = mysqli_fetch_array($query);
          
          $_SESSION['active']=true;
          $_SESSION['a']=$data['Nu_doc'];
          $_SESSION['b']=$data['Primer_nom'];
          $_SESSION['c']=$data['Segundo_nom'];
          $_SESSION['d']=$data['Primer_ape'];
          $_SESSION['e']=$data['Segundo_ape'];

          

          header('location:admin.php');
      }
      else{
        $alert='El usuario o la clave son incorrectos';
       session_destroy();
      }
  }
}
}
?>

<!DOCTYPE html>
<html>
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="estilos1.02021.css">
    <link href="https://fonts.googleapis.com/css?family=Josefin+Sans|Montez|Pathway+Gothic+One" rel="stylesheet">
    <link rel="shortcut icon" href="http://colegiomisaelpastranaborrero.com/img/logo.png" type="Student/favicon.ico">
    <title>Colegio Misael Pastrana Borrero</title>
  </head>
  <body>
      <!-- Header -->
    <nav id="header" class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
        <div class="container ">
            <a class="navbar-brand" href="#">
                <img src="imagenes/logo_colegio.png" alt="Misael Pastrana logo">
                Misael Pastrana Borrero
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbar">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="#main">Inicio</a>
                    </li>
                   
                    <li class="nav-item">
                        <a class="nav-link text-platzi" href='registro.php'>Registrarse</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="cua">
      <div class="login">
        <article class="fondo">
          <img src="imagenes/logo" alt="User">
          <h3>Inicio de Sesión</h3>
          <form class="" action="" method="post">
            <span class="icon-user"></span><input class="inp" type="text" name="numid" value=""><br>
            <span class="icon-key"></span><input class="inp" type="password" name="passwo" value=""><br>
            <div class="alert"><?php echo $alert  ?> </div>
            <input class="boton" type="submit" name="inicio" value="Iniciar Sesión">
          </form>
          
        </article>
      </div>

    </div>
  </body>
</html>