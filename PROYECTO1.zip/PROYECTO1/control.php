<?php
include_once 'model.php';
class control{
    public $MODEL;
    public function _construct(){
        $this->MODEL = new model();
    }
    public function inicio(){
        include 'Iniciar.php';
    }

    public validar(){
        
    }
}

?>
