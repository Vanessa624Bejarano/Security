<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap  -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <!--asomefont-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0-1/css/all.min.css"
        integrity="sha512-wDB6AYiYP4FO5Sxieamqy9wtpAY3qdHMqlhZecIEUu1YjkLw5gQf/4ZDgOzmCBAF5SheMjmugkpUSVoUrGbLkQ=="
        crossorigin="anonymous" />
    <!--maind css-->
    <link rel="stylesheet" href="perfil_admin.css">
    <link rel="shortcut icon" href="http://colegiomisaelpastranaborrero.com/img/logo.png" type="Student/favicon.ico">
    <title>Perfil_admin</title>

</head>

<body class="bodybg">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#"><img src="./imagenes/logo_colegio.png" class="logoi" alt="logo">Misael
                Pastrana
                Moreno</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ullinks">
                    <li class="nav-item">
                        <a class="nav-link" href=Iniciar.php><i class="fas fa-arrow-circle-left  fa-3x"></i></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="index.php">&nbsp;<i
                                class="fas fa-home fa-2x"></i>
                            Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">&nbsp;&nbsp;&nbsp;<i class="far fa-user fa-2x"></i>Admin</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav><br>
    <div class="container-fluid">
        <table class="table">
            <thead class="table-dark">
                <tr>
                    <th scope="col">Id - Admin</Id-docente>
                    </th>
                    <th scope="col">Nombre admin</th>
                    <th scope="col">Apellidos admin</th>
                    <th scope="col">Tipo documento</th>
                </tr>
            </thead>
            <tbody>
                <tr class="table-primary">
                    <th scope="row">000000</th>
                    <td>000000</td>
                    <td>000000</td>
                    <td>000000</td>

                </tr>
            </tbody>
        </table>
        <div class="row">
            <div class="col-4">
                <div id="huella"><a href=registro_usuario.html><i class="fas fa-fingerprint"></i></a></div>
                <h6 class="h2">Registre Huella</h6><br>
                <p class="h5 ">
                    Mostrar Codigo:
                </p>
                <div class="codigo">
                    <i class="fas fa-low-vision ojo"></i>
                    <span class='oculto'>0000</span>
                </div>
            </div>
            <div class="col-2 ">
                <div><a href=registro_usuario.html><i class="fas fa-user-plus user"></i></a></div><br>
                <h6 class="h4">Registrar<br> Nuevo </h6>
            </div>
            <div class="col-6">
                <div class="row">
                    <div><br>
                        <form action="" method="post" target="_blank" class="Search">
                            <p>
                                <input type="search" name="busquedaAlumno" placeholder="Id de usuario Aquí..">
                                <input type="submit"
                                    style="background-color:rgb(0, 93, 233); border-color:rgb(30, 182, 202); color:white"
                                    value="Buscar">
                            </p>

                        </form>
                        <table class="table table-primary  tabla_alumnos ">
                            <thead>
                                <tr>
                                    <th scope="col">Id - alumno</th>
                                    <th scope="col">Nombre Alumno</th>
                                    <th scope="col">Apellidos Alumno</th>
                                    <th scope="col">Jornada</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="table-light">
                                    <td>495</td>
                                    <th>Carlos</th>
                                    <td>Larry </td>
                                    <th>Mixta</th>
                                </tr>
                                <tr class="table-light">
                                    <th>****</th>
                                    <td>****</td>
                                    <td>****</td>
                                    <th>****</th>
                                </tr>
                            </tbody>
                        </table>
                        <table class="table table-primary  tabla_alumnos ">
                            <thead>
                                <tr>
                                    <th scope="col">Id - docente</th>
                                    <th scope="col">Nombre Docente</th>
                                    <th scope="col">Apellidos Docente</th>
                                    <th scope="col">Jornada</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="table-light">
                                    <th>*****</th>
                                    <td>*****</td>
                                    <td>*****</td>
                                    <th>*****</th>
                                </tr>
                                <tr class="table-light">
                                    <th>****</th>
                                    <td>****</td>
                                    <td>****</td>
                                    <th>****</th>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div><br><br>
    <!--footer-->
    <footer class=" footer bg-dark">
        <div class="footer mt-2 container-fluid bg-dark pt-2">
            <div class="float-left m-1">
                <div class="row text-center">
                    <img class="security_logo" src="imagenes/logo.png">
                    <div class="col-12 col-lg">
                        <a href="#">Preguntas frecuentes</a>
                    </div>
                    <div class="col-12 col-lg">
                        <a href="#">Privacidad</a>
                    </div>
                    <div class="col-12 col-lg">
                        <a href="#">Términos y condiciones</a>
                    </div>
                    <div class="col-12 col-lg">
                        <a href="#">Ayuda</a>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Bootstrap Bundle with Popper javascrip-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW"
        crossorigin="anonymous"></script>
</body>

</html>