<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,700&display=swap" rel="stylesheet">
    <link href="https://unpkg.com/ionicons@4.5.10-0/dist/css/ionicons.min.css" rel="stylesheet">
    <link href="style/registro.css" rel="stylesheet">
    <link rel="shortcut icon" href="http://colegiomisaelpastranaborrero.com/img/logo.png" type="Student/favicon.ico">

    <title>Registrarse</title>
</head>

<body>
    <img src="https://www.colegiomisaelpastranaborrero.com/wp-content/uploads/2021/01/Aprende-en-casa-727x1024.png" alt="col-misaelpborrero" class="TRY">
    <section class="contact-box">
        <div class="row no-gutters bg-dark">
            <div class="col-xl-5 col-lg-12 register-bg">
                <div class="position-absolute testiomonial p-4">

                    <h3 class="font-weight-bold text-light">Registrate ya y accede a tu información.</h3>
                    <p class="lead text-light">Facil acceso y mas seguridad en tu institución.</p>

                </div>
            </div>
            <div class="col-xl-7 col-lg-12 d-flex">
                <div class="container align-self-center p-6">
                    <h1 class="font-weight-bold mb-3">Crea tu cuenta gratis</h1>

                    <p class="text-muted mb-5">Ingresa la siguiente información para registrarte.</p>

                    <form action="controller.php" method="post" class="form-register">

                        <label class="font-weight-bold">Selecciona Tu Rol <span class="text-danger">*</span></label>
                        <div class="form-row mb-2">
                            <select name="transporte" class="desplegable">
                        
                            
                            
                                <option value="1">Administrador</option>
                                <option value="2">Docentes</option>
                                <option value="3">Estudiantes</option>
                                <option value="4">Administrador</option>


                            </select>
                        </div>
                        <div class="form-row mb-2">

                            <div class="form-group col-md-6">
                                <label class="font-weight-bold">Nombre <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="name" placeholder="Tu Primer nombre">
                            </div>
                            <div class="form-group col-md-6">
                                <label class="font-weight-bold">Nombre <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="Segundo_nom" placeholder="Tu Segundo nombre">
                            </div>
                            <div class="form-group col-md-6">
                                <label class="font-weight-bold">Apellido <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="apellido" placeholder="Tu apellido">
                            </div>
                            <div class="form-group col-md-6">
                                <label class="font-weight-bold">Apellido <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="Segundo_ape" placeholder="Tu Segundo apellido">
                            </div>
                        </div>
                        <div class="form-row mb-2">
                            <div class="form-group col-md-6">
                                <label class="font-weight-bold">Tipo De Documento <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="tipo_doc" placeholder="TI - CC - CE">
                            </div>
                            <div class="form-group col-md-6">
                                <label class="font-weight-bold">Número De Documento <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="nu_doc" placeholder="Tu Documento">
                            </div>
                        </div>
                        <div class="form-group mb-3">
                            <label class="font-weight-bold">Codigo Asignado <span class="text-danger">*</span></label>
                            <input type="password" class="form-control" name="cod" placeholder="Tu Codigo">
                        </div>
                        <div class="form-group mb-3">
                            <label class="font-weight-bold">Correo electrónico <span class="text-danger">*</span></label>
                            <input type="email" class="form-control" name="cor" placeholder="Ingresa tu correo electrónico">
                        </div>
                        <div class="form-group mb-3">
                            <label class="font-weight-bold">Contraseña <span class="text-danger">*</span></label>
                            <input type="password" name="password" class="form-control" placeholder="Ingresa una contraseña">
                        </div>

                        <div class="form-group mb-5">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox">
                                <label class="form-check-label text-muted">Al seleccionar esta casilla aceptas nuestro
                                    aviso de privacidad y los términos y condiciones</label> 
                            </div>
                        </div>
                        <!--<button class="btn btn-primary width-100">Regístrate</button>-->
                        <input type="submit" name="enviar" value="Enviar">
                    </form>

                    <small class="d-inline-block text-muted mt-5">Todos los derechos reservados | © 2021
                        Security Innovation</small>
                </div>
            </div>
        </div>
    </section>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</body>

</html>