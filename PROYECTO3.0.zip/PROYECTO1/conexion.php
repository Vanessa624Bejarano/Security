<?php 

class conexion //clase principal 
{ 
    public function __construct() //Método Constructor de la clase 
    
    { 
        $this->con = new mysqli("localhost", "root", "", "proyecto1"); // servidor , usuario db,password db, base de datos 
        
        if($this->con->connect_errno) 
        
        { 
            die("Fallo al conectar a la BD: (". $this->con->connect_errno.")"); //Muestra si existe errores 
        } 

    }

} 
    
?>