<?php 

include("clases.php"); //Trae el archivo clases.php en cual se creara más adelante

if(isset($_REQUEST["enviar"])) 
{ // Verifica si el botón oprimido es el de registro

$name=$_REQUEST['name'];
$apellido=$_REQUEST['apellido'];
$tipo_doc=$_REQUEST['tipo_doc'];
$nu_doc=$_REQUEST['nu_doc'];
$password=$_REQUEST['password'];
$transporte=$_REQUEST['transporte'];
$Segundo_nom=$_REQUEST['Segundo_nom'];
$Segundo_ape=$_REQUEST['Segundo_ape'];


$pass = password_hash($password,PASSWORD_DEFAULT); //Encriptación de la contraseña digitada

$objeto= new clases; // Creación de un objeto de la clase clases del archivo clases.php 
$res=$objeto->registro($name,$apellido,$tipo_doc,$nu_doc,$pass,$transporte,$Segundo_nom,$Segundo_ape);

}

$msg="ok";
header("location:Iniciar.php?respuesta=$msg");


?> 
