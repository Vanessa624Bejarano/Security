<?php 

include("conexion.php"); // incluye el archivo conexion.php el cual se conecta a la base de datos

$df=new conexion;

class clases extends conexion 

{ // Crea una clase que hereda de la clase conexión 
    
    public function registro($a,$b,$c,$d,$e,$f,$g,$h) //Método que verifica si el usuario existe 
    { 
        $q = "insert into usuarios (Nu_doc,Tipo_doc,Primer_nom,Segundo_nom,Primer_ape,Segundo_ape,clave,Rol) values('$d','$c','$a','$g','$b','$h','$e','$f')"; 
        $consulta = $this->con->query($q) or die ('Error!' . $this->con->error); 
        return $consulta; 
    }
}
?>