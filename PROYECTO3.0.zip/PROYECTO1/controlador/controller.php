<?php 

include(""); //Trae el archivo clases.php en cual se creara más adelante

if(isset($_REQUEST["enviar"])) 
{ // Verifica si el botón oprimido es el de registro

$name=$_REQUEST['name'];
$apellido=$_REQUEST['apellido'];
$tipo_doc=$_REQUEST['tipo_doc'];
$nu_doc=$_REQUEST['nu_doc'];
$password=$_REQUEST['password'];

$pass = password_hash($password,PASSWORD_DEFAULT); //Encriptación de la contraseña digitada

$objeto= new clases; // Creación de un objeto de la clase clases del archivo clases.php 
$res=$objeto->registro($name,$apellido,$tipo_doc,$nu_doc,$pass);

}

$msg="ok";
header("location:../index.php?respuesta=$msg");


?> 
